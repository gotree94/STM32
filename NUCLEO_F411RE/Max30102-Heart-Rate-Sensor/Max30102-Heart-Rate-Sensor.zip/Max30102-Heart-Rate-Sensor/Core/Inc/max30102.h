/**
  ******************************************************************************
  * @file           : max30102.h
  * @brief          : MAX30102 Heart-Rate Sensor driver header
  ******************************************************************************
  */

#ifndef __MAX30102_H
#define __MAX30102_H

#ifdef __cplusplus
extern "C" {
#endif

#include "main.h"
#include <stdint.h>
#include <stdbool.h>

/* MAX30102 I2C 7-bit address (0x57) */
#define MAX30102_I2C_ADDR         0xAE  /* 0x57 << 1 (8-bit write address for HAL) */

/* ========== Register Map ========== */
#define MAX30102_REG_INTR_STATUS_1    0x00
#define MAX30102_REG_INTR_STATUS_2    0x01
#define MAX30102_REG_INTR_ENABLE_1    0x02
#define MAX30102_REG_INTR_ENABLE_2    0x03
#define MAX30102_REG_FIFO_WR_PTR      0x04
#define MAX30102_REG_OVF_COUNTER      0x05
#define MAX30102_REG_FIFO_RD_PTR      0x06
#define MAX30102_REG_FIFO_DATA        0x07
#define MAX30102_REG_FIFO_CONFIG      0x08
#define MAX30102_REG_MODE_CONFIG      0x09
#define MAX30102_REG_SPO2_CONFIG      0x0A
#define MAX30102_REG_LED1_PA          0x0C  /* IR LED pulse amplitude */
#define MAX30102_REG_LED2_PA          0x0D  /* Red LED pulse amplitude */
#define MAX30102_REG_PILOT_PA         0x10
#define MAX30102_REG_MULTI_LED_CTRL1  0x11
#define MAX30102_REG_MULTI_LED_CTRL2  0x12
#define MAX30102_REG_DIE_TEMP_INT     0x1F
#define MAX30102_REG_DIE_TEMP_FRAC    0x20
#define MAX30102_REG_DIE_TEMP_CONFIG  0x21
#define MAX30102_REG_REV_ID           0xFE
#define MAX30102_REG_PART_ID          0xFF

/* ========== Register Bit Definitions ========== */

/* Mode Config (0x09) */
#define MAX30102_MODE_CONFIG_SHDN     (1 << 7)  /* Shutdown */
#define MAX30102_MODE_CONFIG_RESET    (1 << 6)  /* Software reset */
#define MAX30102_MODE_CONFIG_MODE_POS 0
#define MAX30102_MODE_CONFIG_MODE_MSK (0x07 << 0)
#define MAX30102_MODE_STANDBY         0x00
#define MAX30102_MODE_RED_ONLY        0x01
#define MAX30102_MODE_RED_IR          0x02  /* Red + IR (SpO2 mode) */
#define MAX30102_MODE_MULTI_LED       0x03

/* SPO2 Config (0x0A) */
#define MAX30102_SPO2_ADC_RGE_POS     5
#define MAX30102_SPO2_ADC_RGE_MSK     (0x03 << 5)
#define MAX30102_SPO2_SR_POS          2
#define MAX30102_SPO2_SR_MSK          (0x07 << 2)
#define MAX30102_SPO2_LED_PW_POS      0
#define MAX30102_SPO2_LED_PW_MSK      (0x03 << 0)

/* FIFO Config (0x08) */
#define MAX30102_FIFO_CONFIG_SMP_AVE_POS  5
#define MAX30102_FIFO_CONFIG_SMP_AVE_MSK  (0x07 << 5)
#define MAX30102_FIFO_CONFIG_ROLLOVER_POS 4
#define MAX30102_FIFO_CONFIG_ROLLOVER_MSK (1 << 4)
#define MAX30102_FIFO_CONFIG_AFULL_POS    0
#define MAX30102_FIFO_CONFIG_AFULL_MSK    (0x0F << 0)

/* Interrupt Enable 1 (0x02) */
#define MAX30102_INTR_EN1_FIFO_FULL    (1 << 7)  /* FIFO Almost Full */
#define MAX30102_INTR_EN1_NEW_DATA     (1 << 6)  /* New FIFO Data Ready */
#define MAX30102_INTR_EN1_TEMP_RDY     (1 << 1)  /* Temperature Ready */
#define MAX30102_INTR_EN1_PWR_RDY      (1 << 0)  /* Power Ready */

/* Expected Part ID (0xFF should return 0x15) */
#define MAX30102_EXPECTED_PART_ID      0x15

/* FIFO size (32 samples per channel) */
#define MAX30102_FIFO_DEPTH            32

/* Each FIFO sample: 3 bytes per LED channel */
#define MAX30102_SAMPLE_BYTES          3

/* ========== Data Structures ========== */

typedef struct {
  I2C_HandleTypeDef *hi2c;       /* I2C handle */
  uint8_t   part_id;             /* Part ID from sensor */
  uint8_t   rev_id;              /* Revision ID */
  uint32_t  ir_led_current;      /* IR LED current setting */
  uint32_t  red_led_current;     /* Red LED current setting */
  uint8_t   sample_rate;         /* Samples per second */
  uint8_t   pulse_width;         /* LED pulse width */
} MAX30102_HandleTypeDef;

/* Structure holding one FIFO sample pair */
typedef struct {
  uint32_t  red;    /* Red channel ADC value */
  uint32_t  ir;     /* IR channel ADC value */
} MAX30102_Sample;

/* ========== Function Prototypes ========== */

HAL_StatusTypeDef MAX30102_Init(MAX30102_HandleTypeDef *dev);
HAL_StatusTypeDef MAX30102_Reset(MAX30102_HandleTypeDef *dev);
HAL_StatusTypeDef MAX30102_Shutdown(MAX30102_HandleTypeDef *dev, bool enable);
HAL_StatusTypeDef MAX30102_SetMode(MAX30102_HandleTypeDef *dev, uint8_t mode);
HAL_StatusTypeDef MAX30102_SetLEDPulseAmplitude(MAX30102_HandleTypeDef *dev, uint8_t channel, uint8_t amplitude);
HAL_StatusTypeDef MAX30102_SetSPO2Config(MAX30102_HandleTypeDef *dev, uint8_t adc_range, uint8_t sample_rate, uint8_t pulse_width);
HAL_StatusTypeDef MAX30102_SetFIFOConfig(MAX30102_HandleTypeDef *dev, uint8_t sample_averaging, bool rollover, uint8_t almost_full);
HAL_StatusTypeDef MAX30102_EnableInterrupts(MAX30102_HandleTypeDef *dev, uint8_t flags);

HAL_StatusTypeDef MAX30102_GetPartID(MAX30102_HandleTypeDef *dev, uint8_t *part_id);
HAL_StatusTypeDef MAX30102_GetRevID(MAX30102_HandleTypeDef *dev, uint8_t *rev_id);
HAL_StatusTypeDef MAX30102_GetTemperature(MAX30102_HandleTypeDef *dev, float *temperature);

HAL_StatusTypeDef MAX30102_GetFIFODataCount(MAX30102_HandleTypeDef *dev, uint8_t *count);
HAL_StatusTypeDef MAX30102_ReadFIFOSample(MAX30102_HandleTypeDef *dev, MAX30102_Sample *sample);
HAL_StatusTypeDef MAX30102_ReadFIFOBurst(MAX30102_HandleTypeDef *dev, MAX30102_Sample *samples, uint8_t count);

/* Direct register access (for monitor/debug commands) */
HAL_StatusTypeDef MAX30102_ReadRegister(MAX30102_HandleTypeDef *dev, uint8_t reg, uint8_t *value);
HAL_StatusTypeDef MAX30102_WriteRegister(MAX30102_HandleTypeDef *dev, uint8_t reg, uint8_t value);

/* Utility */
const char* MAX30102_GetStatusString(HAL_StatusTypeDef status);

#ifdef __cplusplus
}
#endif

#endif /* __MAX30102_H */
