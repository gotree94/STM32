/**
  ******************************************************************************
  * @file           : max30102.c
  * @brief          : MAX30102 Heart-Rate Sensor driver (I2C)
  ******************************************************************************
  */

#include "max30102.h"
#include <string.h>

/* I2C timeout in ms */
#define MAX30102_I2C_TIMEOUT    100

/* Max wait loops for reset completion (each ~10ms) */
#define MAX30102_RESET_POLL_MAX 20

/* ========== Private Helpers ========== */

/**
  * @brief  Write a single byte to a MAX30102 register.
  */
static HAL_StatusTypeDef MAX30102_RegWrite(MAX30102_HandleTypeDef *dev,
                                            uint8_t reg, uint8_t data)
{
  return HAL_I2C_Mem_Write(dev->hi2c, MAX30102_I2C_ADDR,
                           reg, I2C_MEMADD_SIZE_8BIT,
                           &data, 1, MAX30102_I2C_TIMEOUT);
}

/**
  * @brief  Read a single byte from a MAX30102 register.
  */
static HAL_StatusTypeDef MAX30102_RegRead(MAX30102_HandleTypeDef *dev,
                                           uint8_t reg, uint8_t *data)
{
  return HAL_I2C_Mem_Read(dev->hi2c, MAX30102_I2C_ADDR,
                          reg, I2C_MEMADD_SIZE_8BIT,
                          data, 1, MAX30102_I2C_TIMEOUT);
}

/**
  * @brief  Read multiple bytes from a MAX30102 register (burst).
  */
static HAL_StatusTypeDef MAX30102_RegReadMulti(MAX30102_HandleTypeDef *dev,
                                                uint8_t reg,
                                                uint8_t *data,
                                                uint16_t len)
{
  return HAL_I2C_Mem_Read(dev->hi2c, MAX30102_I2C_ADDR,
                          reg, I2C_MEMADD_SIZE_8BIT,
                          data, len, MAX30102_I2C_TIMEOUT);
}

/* ========== Public API ========== */

/**
  * @brief  Read a single register from MAX30102 (public wrapper).
  * @param  dev    Device handle
  * @param  reg    Register address
  * @param  value  Pointer to store register value
  */
HAL_StatusTypeDef MAX30102_ReadRegister(MAX30102_HandleTypeDef *dev,
                                         uint8_t reg, uint8_t *value)
{
  return MAX30102_RegRead(dev, reg, value);
}

/**
  * @brief  Write a single register to MAX30102 (public wrapper).
  * @param  dev    Device handle
  * @param  reg    Register address
  * @param  value  Value to write
  */
HAL_StatusTypeDef MAX30102_WriteRegister(MAX30102_HandleTypeDef *dev,
                                          uint8_t reg, uint8_t value)
{
  return MAX30102_RegWrite(dev, reg, value);
}

/* ========== Public API ========== */

/**
  * @brief  Initialize MAX30102 sensor.
  *         Performs reset, verifies part ID, sets default configuration.
  * @param  dev  Pointer to device handle (hi2c must be assigned before call).
  * @retval HAL_OK on success.
  */
HAL_StatusTypeDef MAX30102_Init(MAX30102_HandleTypeDef *dev)
{
  HAL_StatusTypeDef status;
  uint8_t part_id;

  if (dev == NULL || dev->hi2c == NULL)
    return HAL_ERROR;

  /* Software reset */
  status = MAX30102_Reset(dev);
  if (status != HAL_OK) return status;

  /* Verify part ID */
  status = MAX30102_GetPartID(dev, &part_id);
  if (status != HAL_OK) return status;

  if (part_id != MAX30102_EXPECTED_PART_ID)
    return HAL_ERROR;  /* Unknown device or no sensor detected */

  dev->part_id = part_id;

  /* Get revision ID */
  MAX30102_GetRevID(dev, &dev->rev_id);

  /* ---- Default Configuration ---- */

  /* FIFO config: averaging=4, rollover=enabled, almost_full=15 (trigger at 15) */
  status = MAX30102_SetFIFOConfig(dev, 1 /* avg 4 */, true, 15);
  if (status != HAL_OK) return status;

  /* SPO2 config: ADC range=8192nA (balanced sensitivity), sample rate=200Hz, pulse width=411us (18-bit) */
  status = MAX30102_SetSPO2Config(dev, 2 /* 8192nA */,
                                   2 /* 200sps */,
                                   3 /* 411us, 18-bit */);
  if (status != HAL_OK) return status;

  /* LED pulse amplitudes: IR moderate, Red 3x IR to compensate for PD sensitivity */
  /* PD sensitivity: 940nm(IR) ≈ 3× higher than 660nm(Red) at same LED current */
  /* IR LED (channel 0) — 0x40 ≈ 12.5mA */
  status = MAX30102_SetLEDPulseAmplitude(dev, 0, 0x40);
  if (status != HAL_OK) return status;

  /* Red LED (channel 1) — 0xC0 ≈ 38.4mA (3× IR to balance read/receive ratio) */
  status = MAX30102_SetLEDPulseAmplitude(dev, 1, 0xC0);
  if (status != HAL_OK) return status;

  /* Set mode to Red + IR (SpO2 mode) */
  status = MAX30102_SetMode(dev, MAX30102_MODE_RED_IR);
  if (status != HAL_OK) return status;

  return HAL_OK;
}

/**
  * @brief  Perform a software reset of the MAX30102.
  *         Sensor will be in standby after reset completes.
  */
HAL_StatusTypeDef MAX30102_Reset(MAX30102_HandleTypeDef *dev)
{
  HAL_StatusTypeDef status;
  uint8_t reg;
  uint8_t retry;

  /* Set RESET bit in MODE_CONFIG */
  status = MAX30102_RegWrite(dev, MAX30102_REG_MODE_CONFIG,
                             MAX30102_MODE_CONFIG_RESET);
  if (status != HAL_OK) return status;

  /* Wait for reset to complete (sensor clears the RESET bit) */
  retry = MAX30102_RESET_POLL_MAX;
  do {
    HAL_Delay(10);
    status = MAX30102_RegRead(dev, MAX30102_REG_MODE_CONFIG, &reg);
    if (status != HAL_OK) return status;
    retry--;
  } while ((reg & MAX30102_MODE_CONFIG_RESET) && (retry > 0));

  if (reg & MAX30102_MODE_CONFIG_RESET)
    return HAL_TIMEOUT;

  HAL_Delay(10);  /* Additional settling time */
  return HAL_OK;
}

/**
  * @brief  Enable or disable shutdown mode (low-power).
  */
HAL_StatusTypeDef MAX30102_Shutdown(MAX30102_HandleTypeDef *dev, bool enable)
{
  uint8_t reg;
  HAL_StatusTypeDef status;

  status = MAX30102_RegRead(dev, MAX30102_REG_MODE_CONFIG, &reg);
  if (status != HAL_OK) return status;

  if (enable)
    reg |= MAX30102_MODE_CONFIG_SHDN;
  else
    reg &= ~MAX30102_MODE_CONFIG_SHDN;

  return MAX30102_RegWrite(dev, MAX30102_REG_MODE_CONFIG, reg);
}

/**
  * @brief  Set the operating mode.
  * @param  mode  One of MAX30102_MODE_STANDBY, _RED_ONLY, _RED_IR, _MULTI_LED
  */
HAL_StatusTypeDef MAX30102_SetMode(MAX30102_HandleTypeDef *dev, uint8_t mode)
{
  uint8_t reg;
  HAL_StatusTypeDef status;

  status = MAX30102_RegRead(dev, MAX30102_REG_MODE_CONFIG, &reg);
  if (status != HAL_OK) return status;

  reg &= ~MAX30102_MODE_CONFIG_MODE_MSK;
  reg |= (mode & 0x07);

  return MAX30102_RegWrite(dev, MAX30102_REG_MODE_CONFIG, reg);
}

/**
  * @brief  Set LED pulse amplitude.
  * @param  channel   0=IR LED (LED1_PA), 1=Red LED (LED2_PA)
  * @param  amplitude 0x00~0xFF (0=0mA, 0xFF=50mA, linear).
  *                    Typical: 0x1F ~ 6.2mA, 0x40 ~ 12.4mA, 0x80 ~ 25.4mA
  */
HAL_StatusTypeDef MAX30102_SetLEDPulseAmplitude(MAX30102_HandleTypeDef *dev,
                                                 uint8_t channel,
                                                 uint8_t amplitude)
{
  uint8_t reg;

  if (channel == 0)
    reg = MAX30102_REG_LED1_PA;
  else if (channel == 1)
    reg = MAX30102_REG_LED2_PA;
  else
    return HAL_ERROR;

  return MAX30102_RegWrite(dev, reg, amplitude);
}

/**
  * @brief  Configure SPO2 measurement parameters.
  * @param  adc_range    0=2048nA, 1=4096nA, 2=8192nA, 3=16384nA
  * @param  sample_rate  0=50, 1=100, 2=200, 3=400, 4=800, 5=1000 sps
  * @param  pulse_width  0=69us(15bit), 1=118us(16bit), 2=215us(17bit), 3=411us(18bit)
  */
HAL_StatusTypeDef MAX30102_SetSPO2Config(MAX30102_HandleTypeDef *dev,
                                          uint8_t adc_range,
                                          uint8_t sample_rate,
                                          uint8_t pulse_width)
{
  uint8_t reg;

  reg = ((adc_range & 0x03) << MAX30102_SPO2_ADC_RGE_POS) |
        ((sample_rate & 0x07) << MAX30102_SPO2_SR_POS) |
        ((pulse_width & 0x03) << MAX30102_SPO2_LED_PW_POS);

  dev->sample_rate = sample_rate;
  dev->pulse_width = pulse_width;

  return MAX30102_RegWrite(dev, MAX30102_REG_SPO2_CONFIG, reg);
}

/**
  * @brief  Configure the FIFO.
  * @param  sample_averaging  0=1, 1=2, 2=4, 3=8, 4=16, 5=32 samples averaged
  * @param  rollover          true to enable FIFO rollover
  * @param  almost_full       FIFO almost-full value (0-15)
  */
HAL_StatusTypeDef MAX30102_SetFIFOConfig(MAX30102_HandleTypeDef *dev,
                                          uint8_t sample_averaging,
                                          bool rollover,
                                          uint8_t almost_full)
{
  uint8_t reg;

  reg = ((sample_averaging & 0x07) << MAX30102_FIFO_CONFIG_SMP_AVE_POS);
  if (rollover)
    reg |= MAX30102_FIFO_CONFIG_ROLLOVER_MSK;
  reg |= (almost_full & 0x0F);

  return MAX30102_RegWrite(dev, MAX30102_REG_FIFO_CONFIG, reg);
}

/**
  * @brief  Enable specific interrupts.
  * @param  flags  Bitwise OR of MAX30102_INTR_EN1_* flags
  */
HAL_StatusTypeDef MAX30102_EnableInterrupts(MAX30102_HandleTypeDef *dev,
                                             uint8_t flags)
{
  return MAX30102_RegWrite(dev, MAX30102_REG_INTR_ENABLE_1, flags);
}

/* ------------------------------------------------------------------ */
/*  Read operations                                                    */
/* ------------------------------------------------------------------ */

/**
  * @brief  Read the Part ID register (0xFF). Expected value: 0x15.
  */
HAL_StatusTypeDef MAX30102_GetPartID(MAX30102_HandleTypeDef *dev,
                                      uint8_t *part_id)
{
  return MAX30102_RegRead(dev, MAX30102_REG_PART_ID, part_id);
}

/**
  * @brief  Read the Revision ID register (0xFE).
  */
HAL_StatusTypeDef MAX30102_GetRevID(MAX30102_HandleTypeDef *dev,
                                     uint8_t *rev_id)
{
  return MAX30102_RegRead(dev, MAX30102_REG_REV_ID, rev_id);
}

/**
  * @brief  Read die temperature in Celsius.
  */
HAL_StatusTypeDef MAX30102_GetTemperature(MAX30102_HandleTypeDef *dev,
                                           float *temperature)
{
  HAL_StatusTypeDef status;
  uint8_t temp_int, temp_frac;

  /* Trigger temperature measurement */
  status = MAX30102_RegWrite(dev, MAX30102_REG_DIE_TEMP_CONFIG, 0x01);
  if (status != HAL_OK) return status;

  /* Wait for conversion to complete.
   * Instead of polling STATUS_2 (which can have race conditions with
   * the interrupt flag clearing on read), just wait a fixed delay.
   * Typical conversion time is ~30ms; 50ms is generous. */
  HAL_Delay(50);

  /* Read temperature registers */
  status = MAX30102_RegRead(dev, MAX30102_REG_DIE_TEMP_INT, &temp_int);
  if (status != HAL_OK) return status;

  status = MAX30102_RegRead(dev, MAX30102_REG_DIE_TEMP_FRAC, &temp_frac);
  if (status != HAL_OK) return status;

  *temperature = (float)temp_int + ((float)temp_frac * 0.0625f);
  return HAL_OK;
}

/**
  * @brief  Get the number of unread FIFO data samples.
  */
HAL_StatusTypeDef MAX30102_GetFIFODataCount(MAX30102_HandleTypeDef *dev,
                                             uint8_t *count)
{
  HAL_StatusTypeDef status;
  uint8_t wr_ptr, rd_ptr;

  status = MAX30102_RegRead(dev, MAX30102_REG_FIFO_WR_PTR, &wr_ptr);
  if (status != HAL_OK) return status;

  status = MAX30102_RegRead(dev, MAX30102_REG_FIFO_RD_PTR, &rd_ptr);
  if (status != HAL_OK) return status;

  *count = (wr_ptr - rd_ptr) & (MAX30102_FIFO_DEPTH - 1);
  return HAL_OK;
}

/**
  * @brief  Read a single FIFO sample (IR + Red, 6 bytes).
  */
HAL_StatusTypeDef MAX30102_ReadFIFOSample(MAX30102_HandleTypeDef *dev,
                                           MAX30102_Sample *sample)
{
  uint8_t fifo_data[6];
  HAL_StatusTypeDef status;

  status = MAX30102_RegReadMulti(dev, MAX30102_REG_FIFO_DATA,
                                  fifo_data, 6);
  if (status != HAL_OK) return status;

  /* MAX30102 FIFO order in SpO2 mode: [IR_high, IR_mid, IR_low, Red_high, Red_mid, Red_low] */
  sample->ir  = ((uint32_t)fifo_data[0] << 16) |
                ((uint32_t)fifo_data[1] << 8)  |
                (uint32_t)fifo_data[2];
  sample->red = ((uint32_t)fifo_data[3] << 16) |
                ((uint32_t)fifo_data[4] << 8)  |
                (uint32_t)fifo_data[5];

  return HAL_OK;
}

/**
  * @brief  Read multiple FIFO samples in burst.
  * @param  samples  Output array for samples
  * @param  count    Number of samples to read (max ~32)
  */
HAL_StatusTypeDef MAX30102_ReadFIFOBurst(MAX30102_HandleTypeDef *dev,
                                          MAX30102_Sample *samples,
                                          uint8_t count)
{
  HAL_StatusTypeDef status;
  uint8_t fifo_raw[MAX30102_FIFO_DEPTH * 6];  /* Max 32 samples × 6 bytes */
  uint16_t bytes_to_read;
  uint8_t i;

  if (count > MAX30102_FIFO_DEPTH)
    count = MAX30102_FIFO_DEPTH;

  bytes_to_read = count * 6;

  status = MAX30102_RegReadMulti(dev, MAX30102_REG_FIFO_DATA,
                                  fifo_raw, bytes_to_read);
  if (status != HAL_OK) return status;

  for (i = 0; i < count; i++)
  {
    uint8_t *p = &fifo_raw[i * 6];
    samples[i].ir  = ((uint32_t)p[0] << 16) | ((uint32_t)p[1] << 8) | (uint32_t)p[2];
    samples[i].red = ((uint32_t)p[3] << 16) | ((uint32_t)p[4] << 8) | (uint32_t)p[5];
  }

  return HAL_OK;
}

/**
  * @brief  Return a human-readable string for an HAL status.
  */
const char* MAX30102_GetStatusString(HAL_StatusTypeDef status)
{
  switch (status)
  {
    case HAL_OK:       return "OK";
    case HAL_ERROR:    return "ERROR";
    case HAL_BUSY:     return "BUSY";
    case HAL_TIMEOUT:  return "TIMEOUT";
    default:           return "UNKNOWN";
  }
}
