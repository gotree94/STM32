/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "max30102.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
MAX30102_HandleTypeDef max30102 = { .hi2c = &hi2c1 };

/* UART transmit buffer */
static char uart_buf[256];

/* Heartbeat tracking for LED blink */
static uint32_t last_heartbeat_ms = 0;
static uint32_t sample_count = 0;

/* Status flag for sensor health */
static uint8_t sensor_ok = 0;

/* UART command reception (from Python monitor) */
static uint8_t uart_rx_byte;
static char cmd_buffer[64];
static uint8_t cmd_idx = 0;
static volatile uint8_t cmd_ready = 0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_I2C1_Init(void);
/* USER CODE BEGIN PFP */
static void send_cmd_response(const char *resp);
static void process_uart_command(const char *cmd);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_I2C1_Init();
  /* USER CODE BEGIN 2 */
  /* Print startup banner */
  {
    int n = snprintf(uart_buf, sizeof(uart_buf),
      "\r\n===================================\r\n"
      " MAX30102 Heart-Rate Sensor Reader\r\n"
      " MCU: STM32F411RE @ 84MHz\r\n"
      " I2C1: PB8(SCL) PB9(SDA) @ 100kHz\r\n"
      " UART2: PA2(TX) PA3(RX) @ 115200\r\n"
      "===================================\r\n"
    );
    HAL_UART_Transmit(&huart2, (uint8_t*)uart_buf, n, 100);
  }

  /* Initialize MAX30102 sensor */
  HAL_Delay(100);  /* Power-on stabilization */
  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_SET);  /* LED on during init */

  sensor_ok = 0;
  if (MAX30102_Init(&max30102) == HAL_OK)
  {
    uint8_t rev;
    MAX30102_GetRevID(&max30102, &rev);
    int n = snprintf(uart_buf, sizeof(uart_buf),
      "[OK] MAX30102 detected (Part:0x%02X, Rev:0x%02X)\r\n"
      "[OK] Mode: SpO2(Red+IR) | SampleRate: 200sps | Resolution: 18-bit\r\n"
      "[OK] Ready. Reading sensor...\r\n",
      max30102.part_id, rev);
    HAL_UART_Transmit(&huart2, (uint8_t*)uart_buf, n, 100);
    sensor_ok = 1;
  }
  else
  {
    int n = snprintf(uart_buf, sizeof(uart_buf),
      "[FAIL] MAX30102 not detected!\r\n"
      "[INFO] Check wiring: PB8->SCL, PB9->SDA, VIN=3.3V, GND=GND\r\n");
    HAL_UART_Transmit(&huart2, (uint8_t*)uart_buf, n, 100);
  }

  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);  /* LED off */

  /* Print CSV header */
  {
    int n = snprintf(uart_buf, sizeof(uart_buf),
      "\r\n--- CSV DATA ---\r\n"
      "Count,IR_raw,Red_raw\r\n");
    HAL_UART_Transmit(&huart2, (uint8_t*)uart_buf, n, 100);
  }

  /* Start UART RX interrupt for command reception from PC */
  HAL_UART_Receive_IT(&huart2, &uart_rx_byte, 1);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
    while (1)
    {
      /* Process UART commands from Python monitor (if any) */
      if (cmd_ready)
      {
        cmd_ready = 0;
        process_uart_command(cmd_buffer);
      }

      if (sensor_ok)
      {
        /* ----- Read sensor data ----- */
        uint8_t avail = 0;
        MAX30102_Sample sample;

        /* FIX: Read all available samples inside a loop to prevent FIFO overflow
         * and ensure uniform timing interval transmission to Python client */
        if (MAX30102_GetFIFODataCount(&max30102, &avail) == HAL_OK && avail > 0)
        {
          for (uint8_t i = 0; i < avail; i++)
          {
            if (MAX30102_ReadFIFOSample(&max30102, &sample) == HAL_OK)
            {
              sample_count++;

              /* Toggle LD2 on each sample block (activity indicator) */
              if (sample_count % 10 == 0) {
                HAL_GPIO_TogglePin(LD2_GPIO_Port, LD2_Pin);
              }

              /* Print CSV row */
              int n = snprintf(uart_buf, sizeof(uart_buf),
                "%lu,%lu,%lu\r\n",
                (unsigned long)sample_count,
                (unsigned long)sample.ir,
                (unsigned long)sample.red);
              HAL_UART_Transmit(&huart2, (uint8_t*)uart_buf, n, 10);
            }
          }
        }
        else
        {
          /* No data yet — small delay to avoid busy-waiting */
          HAL_Delay(5);
        }

        /* Periodically report temperature (every ~500 samples ~ 5.0s at 100Hz output rate) */
        if (sample_count % 500 == 0 && sample_count > 0)
        {
          float temp;
          if (MAX30102_GetTemperature(&max30102, &temp) == HAL_OK)
          {
            int t_int = (int)temp;
            int t_dec = (int)((temp - (float)t_int) * 100.0f);
            if (t_dec < 0) t_dec = 0;
            int n = snprintf(uart_buf, sizeof(uart_buf),
              "# TEMP: %d.%02d C\r\n", t_int, t_dec);
            HAL_UART_Transmit(&huart2, (uint8_t*)uart_buf, n, 100);
          }
          else
          {
            int n = snprintf(uart_buf, sizeof(uart_buf),
              "# TEMP: READ FAILED\r\n");
            HAL_UART_Transmit(&huart2, (uint8_t*)uart_buf, n, 100);
          }
        }

        /* Heartbeat LED blink (long flash every ~1000 samples) */
        if (sample_count - last_heartbeat_ms >= 1000)
        {
          last_heartbeat_ms = sample_count;
          HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_SET);
          HAL_Delay(50);
          HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);
        }
      }
      else
      {
        /* Sensor not found — keep retrying every 2 seconds */
        HAL_GPIO_TogglePin(LD2_GPIO_Port, LD2_Pin);
        HAL_Delay(2000);

        if (MAX30102_Init(&max30102) == HAL_OK)
        {
          sensor_ok = 1;
          int n = snprintf(uart_buf, sizeof(uart_buf),
            "[OK] MAX30102 reconnected!\r\n");
          HAL_UART_Transmit(&huart2, (uint8_t*)uart_buf, n, 100);
        }
      }
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 100000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : LD2_Pin */
  GPIO_InitStruct.Pin = LD2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LD2_GPIO_Port, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* ── UART Command Processing ──────────────────────────────────────
 *  Protocol (PC → STM32):
 *    "CMD:REG_READ:AA"       → Read register at hex address AA
 *    "CMD:REG_WRITE:AA:VV"   → Write VV to register AA
 *
 *  Response (STM32 → PC):
 *    "[CMD] REG_READ:AA=VV"
 *    "[CMD] REG_WRITE:AA:OK"   or   "[CMD] REG_WRITE:AA:FAIL:reason"
 */

static void send_cmd_response(const char *resp)
{
  int n = snprintf(uart_buf, sizeof(uart_buf), "[CMD] %s\r\n", resp);
  HAL_UART_Transmit(&huart2, (uint8_t*)uart_buf, n, 100);
}

static void process_uart_command(const char *cmd)
{
  /* Parse command type */
  if (strncmp(cmd, "CMD:REG_READ:", 13) == 0)
  {
    const char *addr_str = cmd + 13;
    uint8_t addr = (uint8_t)strtol(addr_str, NULL, 16);
    uint8_t value;

    if (sensor_ok)
    {
      HAL_StatusTypeDef st = MAX30102_ReadRegister(&max30102, addr, &value);
      if (st == HAL_OK)
      {
        int n = snprintf(uart_buf, sizeof(uart_buf),
          "[CMD] REG_READ:%02X=%02X\r\n", addr, value);
        HAL_UART_Transmit(&huart2, (uint8_t*)uart_buf, n, 100);
      }
      else
      {
        send_cmd_response("REG_READ:I2C_FAIL");
      }
    }
    else
    {
      send_cmd_response("REG_READ:SENSOR_NOT_READY");
    }
  }
  else if (strncmp(cmd, "CMD:REG_WRITE:", 14) == 0)
  {
    const char *rest = cmd + 14;
    /* Find colon separator between addr and value */
    const char *colon = strchr(rest, ':');
    if (colon)
    {
      char addr_str[8];
      size_t len = colon - rest;
      if (len > 7) len = 7;
      strncpy(addr_str, rest, len);
      addr_str[len] = '\0';

      uint8_t addr = (uint8_t)strtol(addr_str, NULL, 16);
      uint8_t value = (uint8_t)strtol(colon + 1, NULL, 16);

      if (sensor_ok)
      {
        /* Block writes to FIFO_DATA (0x07) to avoid corrupting the read stream */
        if (addr == 0x07)
        {
          send_cmd_response("REG_WRITE:BLOCKED(FIFO_DATA)");
          return;
        }
        HAL_StatusTypeDef st = MAX30102_WriteRegister(&max30102, addr, value);
        if (st == HAL_OK)
        {
          int n = snprintf(uart_buf, sizeof(uart_buf),
            "[CMD] REG_WRITE:%02X:OK\r\n", addr);
          HAL_UART_Transmit(&huart2, (uint8_t*)uart_buf, n, 100);
        }
        else
        {
          send_cmd_response("REG_WRITE:I2C_FAIL");
        }
      }
      else
      {
        send_cmd_response("REG_WRITE:SENSOR_NOT_READY");
      }
    }
  }
  else if (strcmp(cmd, "CMD:GET_TEMP") == 0)
  {
    if (sensor_ok)
    {
      float temp;
      if (MAX30102_GetTemperature(&max30102, &temp) == HAL_OK)
      {
        int n = snprintf(uart_buf, sizeof(uart_buf),
          "[CMD] TEMP=%.2f\r\n", temp);
        HAL_UART_Transmit(&huart2, (uint8_t*)uart_buf, n, 100);
      }
      else
      {
        send_cmd_response("TEMP:READ_FAILED");
      }
    }
    else
    {
      send_cmd_response("TEMP:SENSOR_NOT_READY");
    }
  }
}

/**
  * @brief  UART RX interrupt callback (called from HAL on each received byte).
  */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
  if (huart->Instance == USART2)
  {
    if (uart_rx_byte == '\n' && cmd_idx > 0)
    {
      cmd_buffer[cmd_idx] = '\0';
      cmd_ready = 1;
      cmd_idx = 0;
    }
    else if (uart_rx_byte != '\r' && cmd_idx < sizeof(cmd_buffer) - 1)
    {
      cmd_buffer[cmd_idx++] = uart_rx_byte;
    }
    /* Re-arm RX interrupt */
    HAL_UART_Receive_IT(&huart2, &uart_rx_byte, 1);
  }
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
